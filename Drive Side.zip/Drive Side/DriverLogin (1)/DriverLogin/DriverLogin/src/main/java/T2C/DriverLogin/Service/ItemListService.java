package T2C.DriverLogin.Service;


import T2C.DriverLogin.DTO.ItemListDto;

import java.util.List;

public interface ItemListService {
    List<ItemListDto> getAllItems();
    ItemListDto getItemById(int id);
    ItemListDto createItem(ItemListDto itemListDto);
    ItemListDto updateItem(int id, ItemListDto itemListDto);
    void deleteItem(int id);
}
