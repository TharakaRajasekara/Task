package T2C.DriverLogin.Repository;

import T2C.DriverLogin.Entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository1 extends JpaRepository<UserEntity, Long> {

}