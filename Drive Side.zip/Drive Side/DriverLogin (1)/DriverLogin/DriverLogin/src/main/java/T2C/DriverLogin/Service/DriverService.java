package T2C.DriverLogin.Service;

import T2C.DriverLogin.DTO.DriverDTO;

import java.util.List;

public interface DriverService {
    DriverDTO createDriver(DriverDTO driverDTO);
    List<DriverDTO> getAllDrivers();
    // other methods
}
