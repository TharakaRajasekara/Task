package T2C.DriverLogin.Service.IMPL;

import T2C.DriverLogin.DTO.HomePointDTO;
import T2C.DriverLogin.Entity.HomePoint;
import T2C.DriverLogin.Repository.*;
import T2C.DriverLogin.Service.HomePointService;

import T2C.DriverLogin.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class HomePointServiceImpl implements HomePointService {

    @Autowired
    private HomePointRepository homePointRepository;

    @Autowired
    private UserRepository userRepository; // assuming UserRepository is available
    @Autowired
    private TimeslotRepository timeslotRepository; // assuming TimeslotRepository is available
    @Autowired
    private PickupStatusRepository pickupStatusRepository; // assuming PickupStatusRepository is available
    @Autowired
    private ItemListRepository itemListRepository; // assuming ItemListRepository is available
    @Autowired
    private DriverRepository driverRepository; // assuming DriverRepository is available

    @Override
    public List<HomePointDTO> getAllHomePoints() {
        return homePointRepository.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public HomePointDTO getHomePointById(int hpId) {
        return homePointRepository.findById(hpId).map(this::convertToDTO).orElseThrow(() -> new ResourceNotFoundException("HomePoint not found"));
    }

    @Override
    public HomePointDTO createHomePoint(HomePointDTO homePointDTO) {
        HomePoint homePoint = convertToEntity(homePointDTO);
        return convertToDTO(homePointRepository.save(homePoint));
    }

    @Override
    public HomePointDTO updateHomePoint(int hpId, HomePointDTO homePointDTO) {
        HomePoint homePoint = homePointRepository.findById(hpId).orElseThrow(() -> new ResourceNotFoundException("HomePoint not found"));
        homePoint.setUser(userRepository.findById(homePointDTO.getUserId()).orElseThrow(() -> new ResourceNotFoundException("User not found")));
        homePoint.setTimeslot(timeslotRepository.findById(homePointDTO.getTimeslotId()).orElseThrow(() -> new ResourceNotFoundException("Timeslot not found")));
        homePoint.setPoints(homePointDTO.getPoints());
        homePoint.setPickupStatus(pickupStatusRepository.findById(homePointDTO.getPickupStatusId()).orElseThrow(() -> new ResourceNotFoundException("PickupStatus not found")));
        homePoint.setLocation(homePointDTO.getLocation());
        homePoint.setItemList(itemListRepository.findById(homePointDTO.getItemListId()).orElseThrow(() -> new ResourceNotFoundException("ItemList not found")));
        homePoint.setDriver(driverRepository.findById(homePointDTO.getDriverId()).orElseThrow(() -> new ResourceNotFoundException("Driver not found")));
        return convertToDTO(homePointRepository.save(homePoint));
    }

    @Override
    public void deleteHomePoint(int hpId) {
        homePointRepository.deleteById(hpId);
    }

    private HomePointDTO convertToDTO(HomePoint homePoint) {
        HomePointDTO dto = new HomePointDTO();
        dto.setHpId(homePoint.getHpId());
        dto.setUserId(homePoint.getUser().getUserId());
        dto.setTimeslotId(homePoint.getTimeslot().getId());
        dto.setPoints(homePoint.getPoints());
        dto.setPickupStatusId(homePoint.getPickupStatus().getId());
        dto.setLocation(homePoint.getLocation());
        dto.setItemListId(homePoint.getItemList().getId());
        dto.setDriverId(homePoint.getDriver().getDriverId());
        return dto;
    }

    private HomePoint convertToEntity(HomePointDTO dto) {
        HomePoint homePoint = new HomePoint();
        homePoint.setUser(userRepository.findById(dto.getUserId()).orElseThrow(() -> new ResourceNotFoundException("User not found")));
        homePoint.setTimeslot(timeslotRepository.findById(dto.getTimeslotId()).orElseThrow(() -> new ResourceNotFoundException("Timeslot not found")));
        homePoint.setPoints(dto.getPoints());
        homePoint.setPickupStatus(pickupStatusRepository.findById(dto.getPickupStatusId()).orElseThrow(() -> new ResourceNotFoundException("PickupStatus not found")));
        homePoint.setLocation(dto.getLocation());
        homePoint.setItemList(itemListRepository.findById(dto.getItemListId()).orElseThrow(() -> new ResourceNotFoundException("ItemList not found")));
        homePoint.setDriver(driverRepository.findById(dto.getDriverId()).orElseThrow(() -> new ResourceNotFoundException("Driver not found")));
        return homePoint;
    }
}
