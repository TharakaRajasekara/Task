package T2C.DriverLogin.Controller;
import T2C.DriverLogin.DTO.ItemListDto;
import T2C.DriverLogin.Service.ItemListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/items")
public class ItemListController {

    @Autowired
    private ItemListService itemListService;

    @GetMapping
    public List<ItemListDto> getAllItems() {
        return itemListService.getAllItems();
    }

    @GetMapping("/{id}")
    public ItemListDto getItemById(@PathVariable int id) {
        return itemListService.getItemById(id);
    }

    @PostMapping
    public ItemListDto createItem(@RequestBody ItemListDto itemListDto) {
        return itemListService.createItem(itemListDto);
    }

    @PutMapping("/{id}")
    public ItemListDto updateItem(@PathVariable int id, @RequestBody ItemListDto itemListDto) {
        return itemListService.updateItem(id, itemListDto);
    }

    @DeleteMapping("/{id}")
    public void deleteItem(@PathVariable int id) {
        itemListService.deleteItem(id);
    }
}
