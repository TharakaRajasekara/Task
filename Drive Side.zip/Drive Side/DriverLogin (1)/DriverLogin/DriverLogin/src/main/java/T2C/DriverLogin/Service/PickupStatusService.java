package T2C.DriverLogin.Service;


import T2C.DriverLogin.DTO.PickupStatusDTO;

import java.util.List;

public interface PickupStatusService {

    List<PickupStatusDTO> getAllStatuses();

    PickupStatusDTO getStatusById(Integer id);

    PickupStatusDTO createStatus(PickupStatusDTO pickupStatusDTO);

    PickupStatusDTO updateStatus(Integer id, PickupStatusDTO pickupStatusDTO);

    void deleteStatus(Integer id);
}
