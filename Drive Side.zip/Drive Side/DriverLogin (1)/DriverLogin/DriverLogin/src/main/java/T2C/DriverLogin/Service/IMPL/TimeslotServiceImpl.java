package T2C.DriverLogin.Service.IMPL;
import T2C.DriverLogin.DTO.TimeslotDTO;
import T2C.DriverLogin.Entity.Timeslot;
import T2C.DriverLogin.Repository.TimeslotRepository;
import T2C.DriverLogin.Service.TimeslotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TimeslotServiceImpl implements TimeslotService {

    @Autowired
    private TimeslotRepository timeslotRepository;

    @Override
    public TimeslotDTO createTimeslot(TimeslotDTO timeslotDTO) {
        Timeslot timeslot = new Timeslot();
        timeslot.setDate(timeslotDTO.getDate());
        timeslot.setFrom(timeslotDTO.getFrom());
        timeslot.setTo(timeslotDTO.getTo());
        timeslot = timeslotRepository.save(timeslot);
        return convertEntityToDto(timeslot);
    }

    @Override
    public TimeslotDTO getTimeslotById(int id) {
        Timeslot timeslot = timeslotRepository.findById(id).orElseThrow(() -> new RuntimeException("Timeslot not found"));
        return convertEntityToDto(timeslot);
    }

    @Override
    public List<TimeslotDTO> getAllTimeslots() {
        return timeslotRepository.findAll().stream().map(this::convertEntityToDto).collect(Collectors.toList());
    }

    @Override
    public TimeslotDTO updateTimeslot(int id, TimeslotDTO timeslotDTO) {
        Timeslot timeslot = timeslotRepository.findById(id).orElseThrow(() -> new RuntimeException("Timeslot not found"));
        timeslot.setDate(timeslotDTO.getDate());
        timeslot.setFrom(timeslotDTO.getFrom());
        timeslot.setTo(timeslotDTO.getTo());
        timeslot = timeslotRepository.save(timeslot);
        return convertEntityToDto(timeslot);
    }

    @Override
    public void deleteTimeslot(int id) {
        Timeslot timeslot = timeslotRepository.findById(id).orElseThrow(() -> new RuntimeException("Timeslot not found"));
        timeslotRepository.delete(timeslot);
    }

    private TimeslotDTO convertEntityToDto(Timeslot timeslot) {
        TimeslotDTO timeslotDTO = new TimeslotDTO();
        timeslotDTO.setId(timeslot.getId());
        timeslotDTO.setDate(timeslot.getDate());
        timeslotDTO.setFrom(timeslot.getFrom());
        timeslotDTO.setTo(timeslot.getTo());
        return timeslotDTO;
    }
}
