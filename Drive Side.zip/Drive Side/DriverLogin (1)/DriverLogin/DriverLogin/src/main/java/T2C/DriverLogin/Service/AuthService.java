package T2C.DriverLogin.Service;

import T2C.DriverLogin.DTO.UserDTO;

public interface AuthService {
    boolean loginUser(UserDTO user);
}
