package T2C.DriverLogin.Service.IMPL;


import T2C.DriverLogin.DTO.PickupStatusDTO;
import T2C.DriverLogin.Entity.PickupStatus;
import T2C.DriverLogin.Repository.PickupStatusRepository;
import T2C.DriverLogin.Service.PickupStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PickupStatusServiceImpl implements PickupStatusService {

    @Autowired
    private PickupStatusRepository pickupStatusRepository;

    @Override
    public List<PickupStatusDTO> getAllStatuses() {
        return pickupStatusRepository.findAll().stream().map(this::convertEntityToDto).collect(Collectors.toList());
    }

    @Override
    public PickupStatusDTO getStatusById(Integer id) {
        return pickupStatusRepository.findById(id).map(this::convertEntityToDto).orElse(null);
    }

    @Override
    public PickupStatusDTO createStatus(PickupStatusDTO pickupStatusDTO) {
        PickupStatus pickupStatus = new PickupStatus();
        pickupStatus.setStatus(pickupStatusDTO.getStatus());
        PickupStatus savedStatus = pickupStatusRepository.save(pickupStatus);
        return convertEntityToDto(savedStatus);
    }

    @Override
    public PickupStatusDTO updateStatus(Integer id, PickupStatusDTO pickupStatusDTO) {
        PickupStatus pickupStatus = pickupStatusRepository.findById(id).orElseThrow(() -> new RuntimeException("Status not found"));
        pickupStatus.setStatus(pickupStatusDTO.getStatus());
        PickupStatus updatedStatus = pickupStatusRepository.save(pickupStatus);
        return convertEntityToDto(updatedStatus);
    }

    @Override
    public void deleteStatus(Integer id) {
        pickupStatusRepository.deleteById(id);
    }

    private PickupStatusDTO convertEntityToDto(PickupStatus pickupStatus) {
        PickupStatusDTO dto = new PickupStatusDTO();
        dto.setId(pickupStatus.getId());
        dto.setStatus(pickupStatus.getStatus());
        return dto;
    }
}
