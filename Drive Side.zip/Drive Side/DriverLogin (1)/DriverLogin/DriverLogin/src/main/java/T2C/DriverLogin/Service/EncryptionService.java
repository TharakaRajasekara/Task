package T2C.DriverLogin.Service;

import org.jasypt.util.text.BasicTextEncryptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class EncryptionService {

    private final BasicTextEncryptor textEncryptor;

    public EncryptionService(@Value("${jasypt.encryptor.password}") String secretKey) {
        textEncryptor = new BasicTextEncryptor();
        textEncryptor.setPassword(secretKey);
    }

    public String encrypt(String data) {
        return textEncryptor.encrypt(data);
    }

    public String decrypt(String encryptedData) {
        return textEncryptor.decrypt(encryptedData);
    }
}
