package T2C.DriverLogin.Controller;

import T2C.DriverLogin.DTO.UserDTO1;
import T2C.DriverLogin.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;




@RestController
public class UserController {


    @Autowired
    private UserService userService;

    @GetMapping("/user/profile")
    public UserDTO1 getUserProfile() {
        return userService.getUserProfile();
    }
}