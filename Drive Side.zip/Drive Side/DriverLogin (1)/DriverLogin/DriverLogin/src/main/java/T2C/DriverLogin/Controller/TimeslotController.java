package T2C.DriverLogin.Controller;
import T2C.DriverLogin.DTO.TimeslotDTO;
import T2C.DriverLogin.Service.TimeslotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/timeslots")
public class TimeslotController {

    @Autowired
    private TimeslotService timeslotService;

    @PostMapping
    public ResponseEntity<TimeslotDTO> createTimeslot(@RequestBody TimeslotDTO timeslotDTO) {
        return ResponseEntity.ok(timeslotService.createTimeslot(timeslotDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<TimeslotDTO> getTimeslotById(@PathVariable int id) {
        return ResponseEntity.ok(timeslotService.getTimeslotById(id));
    }

    @GetMapping
    public ResponseEntity<List<TimeslotDTO>> getAllTimeslots() {
        return ResponseEntity.ok(timeslotService.getAllTimeslots());
    }

    @PutMapping("/{id}")
    public ResponseEntity<TimeslotDTO> updateTimeslot(@PathVariable int id, @RequestBody TimeslotDTO timeslotDTO) {
        return ResponseEntity.ok(timeslotService.updateTimeslot(id, timeslotDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTimeslot(@PathVariable int id) {
        timeslotService.deleteTimeslot(id);
        return ResponseEntity.noContent().build();
    }
}
