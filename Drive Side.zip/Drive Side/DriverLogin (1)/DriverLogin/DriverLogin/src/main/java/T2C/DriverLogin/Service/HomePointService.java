package T2C.DriverLogin.Service;

import T2C.DriverLogin.DTO.HomePointDTO;

import java.util.List;

public interface HomePointService {

    List<HomePointDTO> getAllHomePoints();
    HomePointDTO getHomePointById(int hpId);
    HomePointDTO createHomePoint(HomePointDTO homePointDTO);
    HomePointDTO updateHomePoint(int hpId, HomePointDTO homePointDTO);
    void deleteHomePoint(int hpId);

}
