package T2C.DriverLogin.Repository;

import T2C.DriverLogin.Entity.Driver;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface DriverRepository extends JpaRepository<Driver, Long> {
    // You can add custom queries here if needed
}