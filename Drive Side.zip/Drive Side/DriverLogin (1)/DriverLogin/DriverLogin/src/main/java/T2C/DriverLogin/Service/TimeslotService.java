package T2C.DriverLogin.Service;


import T2C.DriverLogin.DTO.TimeslotDTO;

import java.util.List;

public interface TimeslotService {
    TimeslotDTO createTimeslot(TimeslotDTO timeslotDTO);
    TimeslotDTO getTimeslotById(int id);
    List<TimeslotDTO> getAllTimeslots();
    TimeslotDTO updateTimeslot(int id, TimeslotDTO timeslotDTO);
    void deleteTimeslot(int id);
}
