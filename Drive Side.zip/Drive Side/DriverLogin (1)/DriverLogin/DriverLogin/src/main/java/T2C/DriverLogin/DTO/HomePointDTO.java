package T2C.DriverLogin.DTO;

public class HomePointDTO {

    private int hpId;
    private int userId;
    private int timeslotId;
    private int points;
    private int pickupStatusId;
    private String location;
    private int itemListId;
    private int driverId;

    // Getters and setters

    public HomePointDTO() {
    }

    public HomePointDTO(int hpId, int userId, int timeslotId, int points, int pickupStatusId, String location, int itemListId, int driverId) {
        this.hpId = hpId;
        this.userId = userId;
        this.timeslotId = timeslotId;
        this.points = points;
        this.pickupStatusId = pickupStatusId;
        this.location = location;
        this.itemListId = itemListId;
        this.driverId = driverId;
    }

    public int getHpId() {
        return hpId;
    }

    public void setHpId(int hpId) {
        this.hpId = hpId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getTimeslotId() {
        return timeslotId;
    }

    public void setTimeslotId(int timeslotId) {
        this.timeslotId = timeslotId;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getPickupStatusId() {
        return pickupStatusId;
    }

    public void setPickupStatusId(int pickupStatusId) {
        this.pickupStatusId = pickupStatusId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getItemListId() {
        return itemListId;
    }

    public void setItemListId(int itemListId) {
        this.itemListId = itemListId;
    }

    public long getDriverId() {
        return driverId;
    }

    public void setDriverId(int driverId) {
        this.driverId = driverId;
    }

    @Override
    public String toString() {
        return "HomePointDTO{" +
                "hpId=" + hpId +
                ", userId=" + userId +
                ", timeslotId=" + timeslotId +
                ", points=" + points +
                ", pickupStatusId=" + pickupStatusId +
                ", location='" + location + '\'' +
                ", itemListId=" + itemListId +
                ", driverId=" + driverId +
                '}';
    }
}
