package T2C.DriverLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriverLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
