package ttc.driver.entity;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer user_id;

    private String name;

    private String email;

    private String mobile;

    @Column(columnDefinition = "TEXT")
    private String pfp_link;

    private Integer available_points;

    private Timestamp created_at;

    private Timestamp updated_at;

    // Getters
    public Integer getUser_id() {
        return user_id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getMobile() {
        return mobile;
    }

    public String getPfp_link() {
        return pfp_link;
    }

    public Integer getAvailable_points() {
        return available_points;
    }

    public Timestamp getCreated_at() {
        return created_at;
    }

    public Timestamp getUpdated_at() {
        return updated_at;
    }

    // Setters
    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setPfp_link(String pfp_link) {
        this.pfp_link = pfp_link;
    }

    public void setAvailable_points(Integer available_points) {
        this.available_points = available_points;
    }

    public void setCreated_at(Timestamp created_at) {
        this.created_at = created_at;
    }

    public void setUpdated_at(Timestamp updated_at) {
        this.updated_at = updated_at;
    }

    @Override
    public String toString() {
        return "User{" +
                "user_id=" + user_id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", mobile='" + mobile + '\'' +
                ", pfp_link='" + pfp_link + '\'' +
                ", available_points=" + available_points +
                ", created_at=" + created_at +
                ", updated_at=" + updated_at +
                '}';
    }

    // Corrected getId method
    public Integer getId() {
        return user_id;
    }

    public int getUserId() {
        return 0;
    }
}
