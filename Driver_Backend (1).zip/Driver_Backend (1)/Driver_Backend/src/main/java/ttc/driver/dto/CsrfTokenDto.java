package ttc.driver.dto;

public class CsrfTokenDto {

    private Long id;
    private String parameterName;
    private String token;
    private String headerName;

    // Constructors, getters, and setters

    public CsrfTokenDto() {}

    public CsrfTokenDto(Long id, String parameterName, String token, String headerName) {
        this.id = id;
        this.parameterName = parameterName;
        this.token = token;
        this.headerName = headerName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getParameterName() {
        return parameterName;
    }

    public void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getHeaderName() {
        return headerName;
    }

    public void setHeaderName(String headerName) {
        this.headerName = headerName;
    }

    @Override
    public String toString() {
        return "CsrfTokenDto{" +
                "id=" + id +
                ", parameterName='" + parameterName + '\'' +
                ", token='" + token + '\'' +
                ", headerName='" + headerName + '\'' +
                '}';
    }
}