package ttc.driver.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ttc.driver.dto.DriverStatusDTO;
import ttc.driver.entity.DriverStatus;
import ttc.driver.repository.DriverStatusRepository;
import ttc.driver.service.DriverStatusService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DriverStatusServiceImpl implements DriverStatusService {

    @Autowired
    private DriverStatusRepository driverStatusRepository;

    @Override
    public DriverStatusDTO createDriverStatus(DriverStatusDTO driverStatusDTO) {
        DriverStatus driverStatus = convertToEntity(driverStatusDTO);
        driverStatus = driverStatusRepository.save(driverStatus);
        return convertToDTO(driverStatus);
    }

    @Override
    public DriverStatusDTO updateDriverStatus(int id, DriverStatusDTO driverStatusDTO) {
        DriverStatus driverStatus = driverStatusRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("DriverStatus not found"));
        driverStatus.setStatus(driverStatusDTO.getStatus());
        driverStatus = driverStatusRepository.save(driverStatus);
        return convertToDTO(driverStatus);
    }

    @Override
    public void deleteDriverStatus(int id) {
        driverStatusRepository.deleteById(id);
    }

    @Override
    public DriverStatusDTO getDriverStatusById(int id) {
        DriverStatus driverStatus = driverStatusRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("DriverStatus not found"));
        return convertToDTO(driverStatus);
    }

    @Override
    public List<DriverStatusDTO> getAllDriverStatuses() {
        return driverStatusRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    private DriverStatus convertToEntity(DriverStatusDTO driverStatusDTO) {
        DriverStatus driverStatus = new DriverStatus();
        driverStatus.setId(driverStatusDTO.getId());
        driverStatus.setStatus(driverStatusDTO.getStatus());
        return driverStatus;
    }

    private DriverStatusDTO convertToDTO(DriverStatus driverStatus) {
        DriverStatusDTO driverStatusDTO = new DriverStatusDTO();
        driverStatusDTO.setId(driverStatus.getId());
        driverStatusDTO.setStatus(driverStatus.getStatus());
        return driverStatusDTO;
    }
}
