package ttc.driver.service;

import ttc.driver.dto.DriverDTO;

import java.util.List;

public interface DriverService {
    DriverDTO createDriver(DriverDTO driverDTO);
    DriverDTO updateDriver(int id, DriverDTO driverDTO);
    void deleteDriver(int id);
    DriverDTO getDriverById(int id);
    List<DriverDTO> getAllDrivers();
}
