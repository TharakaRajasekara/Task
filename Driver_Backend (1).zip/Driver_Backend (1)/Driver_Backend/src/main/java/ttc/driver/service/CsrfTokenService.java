package ttc.driver.service;


import ttc.driver.dto.CsrfTokenDto;

import java.util.List;

public interface CsrfTokenService {

    CsrfTokenDto createCsrfToken(CsrfTokenDto csrfTokenDto);

    CsrfTokenDto getCsrfTokenById(Long id);

    List<CsrfTokenDto> getAllCsrfTokens();

    CsrfTokenDto updateCsrfToken(Long id, CsrfTokenDto csrfTokenDto);

    void deleteCsrfToken(Long id);
}