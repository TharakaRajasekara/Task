package ttc.driver.service;


import java.util.List;

import ttc.driver.dto.ItemListDto;

public interface ItemListService {
    List<ItemListDto> getAllItems();
    ItemListDto getItemById(int id);
    ItemListDto createItem(ItemListDto itemListDto);
    ItemListDto updateItem(int id, ItemListDto itemListDto);
    void deleteItem(int id);
}
