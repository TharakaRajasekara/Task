package ttc.driver.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ttc.driver.dto.HomePointDTO;
import ttc.driver.entity.HomePoint;
import ttc.driver.entity.User;
import ttc.driver.repository.HomePointRepository;
import ttc.driver.repository.UserRepository;
import ttc.driver.service.HomePointService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class HomePointServiceImpl implements HomePointService {

    @Autowired
    private HomePointRepository homePointRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public HomePointDTO createHomePoint(HomePointDTO homePointDTO) {
        HomePoint homePoint = new HomePoint();
        homePoint.setHpId(homePointDTO.getHpId());
        User user = userRepository.findById(homePointDTO.getUserId()).orElseThrow(() -> new RuntimeException("User not found"));
        homePoint.setUser(user);
        homePoint.setTimeslotId(homePointDTO.getTimeslotId());
        homePoint.setLocation(homePointDTO.getLocation());
        homePoint.setItemListId(homePointDTO.getItemListId());
        homePoint = homePointRepository.save(homePoint);
        return convertToDTO(homePoint);
    }

    @Override
    public HomePointDTO updateHomePoint(int hpId, HomePointDTO homePointDTO) {
        HomePoint homePoint = homePointRepository.findById(hpId).orElseThrow(() -> new RuntimeException("HomePoint not found"));
        User user = userRepository.findById(homePointDTO.getUserId()).orElseThrow(() -> new RuntimeException("User not found"));
        homePoint.setUser(user);
        homePoint.setTimeslotId(homePointDTO.getTimeslotId());
        homePoint.setLocation(homePointDTO.getLocation());
        homePoint.setItemListId(homePointDTO.getItemListId());
        homePoint = homePointRepository.save(homePoint);
        return convertToDTO(homePoint);
    }

    @Override
    public void deleteHomePoint(int hpId) {
        homePointRepository.deleteById(hpId);
    }

    @Override
    public HomePointDTO getHomePointById(int hpId) {
        HomePoint homePoint = homePointRepository.findById(hpId).orElseThrow(() -> new RuntimeException("HomePoint not found"));
        return convertToDTO(homePoint);
    }

    @Override
    public List<HomePointDTO> getAllHomePoints() {
        return homePointRepository.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    private HomePointDTO convertToDTO(HomePoint homePoint) {
        return new HomePointDTO(
                homePoint.getHpId(),
                homePoint.getUser().getUser_id(),
                homePoint.getTimeslotId(),
                homePoint.getLocation(),
                homePoint.getItemListId()
        );
    }
}

