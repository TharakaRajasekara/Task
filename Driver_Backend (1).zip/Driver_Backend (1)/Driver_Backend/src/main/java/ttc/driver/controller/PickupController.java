package ttc.driver.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ttc.driver.dto.PickupDTO;
import ttc.driver.service.PickupService;

import java.util.List;

@RestController
@RequestMapping("/pickups")
public class PickupController {

    @Autowired
    private PickupService pickupService;

    @PostMapping
    public ResponseEntity<PickupDTO> createPickup(@RequestBody PickupDTO pickupDTO) {
        PickupDTO createdPickup = pickupService.createPickup(pickupDTO);
        return ResponseEntity.ok(createdPickup);
    }

    @PutMapping("/{hpId}")
    public ResponseEntity<PickupDTO> updatePickup(@PathVariable int hpId, @RequestBody PickupDTO pickupDTO) {
        PickupDTO updatedPickup = pickupService.updatePickup(hpId, pickupDTO);
        return ResponseEntity.ok(updatedPickup);
    }

    @DeleteMapping("/{hpId}")
    public ResponseEntity<Void> deletePickup(@PathVariable int hpId) {
        pickupService.deletePickup(hpId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{hpId}")
    public ResponseEntity<PickupDTO> getPickupById(@PathVariable int hpId) {
        PickupDTO pickupDTO = pickupService.getPickupById(hpId);
        return ResponseEntity.ok(pickupDTO);
    }

    @GetMapping
    public ResponseEntity<List<PickupDTO>> getAllPickups() {
        List<PickupDTO> pickups = pickupService.getAllPickups();
        return ResponseEntity.ok(pickups);
    }
}
