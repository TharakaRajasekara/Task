package ttc.driver.service.impl;

import ttc.driver.dto.UserDTO;
import ttc.driver.entity.User;
import ttc.driver.repository.UserRepository;
import ttc.driver.service.UserService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;

    @Override

    public UserDTO getUserProfile() {
        List<User> userEntity = userRepository.findAll(); // Assuming user ID 1 for simplicity
        if (userEntity != null) {
            UserDTO userDTO = new UserDTO();
            return userDTO;
        }
        return null;
    }
}