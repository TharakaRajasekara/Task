package ttc.driver.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import ttc.driver.entity.Pickup;

public interface PickupRepository extends JpaRepository<Pickup, Integer> {
}

