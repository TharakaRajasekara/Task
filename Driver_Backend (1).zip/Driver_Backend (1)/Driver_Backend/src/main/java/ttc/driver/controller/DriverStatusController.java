package ttc.driver.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ttc.driver.dto.DriverStatusDTO;
import ttc.driver.service.DriverStatusService;

import java.util.List;

@RestController
@RequestMapping("/api/driver-statuses")
public class DriverStatusController {

    @Autowired
    private DriverStatusService driverStatusService;

    @PostMapping
    public ResponseEntity<DriverStatusDTO> createDriverStatus(@RequestBody DriverStatusDTO driverStatusDTO) {
        return ResponseEntity.ok(driverStatusService.createDriverStatus(driverStatusDTO));
    }

    @PutMapping("/{id}")
    public ResponseEntity<DriverStatusDTO> updateDriverStatus(@PathVariable int id, @RequestBody DriverStatusDTO driverStatusDTO) {
        return ResponseEntity.ok(driverStatusService.updateDriverStatus(id, driverStatusDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDriverStatus(@PathVariable int id) {
        driverStatusService.deleteDriverStatus(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<DriverStatusDTO> getDriverStatusById(@PathVariable int id) {
        return ResponseEntity.ok(driverStatusService.getDriverStatusById(id));
    }

    @GetMapping
    public ResponseEntity<List<DriverStatusDTO>> getAllDriverStatuses() {
        return ResponseEntity.ok(driverStatusService.getAllDriverStatuses());
    }
}
