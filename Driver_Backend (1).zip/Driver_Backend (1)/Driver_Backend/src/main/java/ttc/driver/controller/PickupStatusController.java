package ttc.driver.controller;

import ttc.driver.dto.PickupStatusDTO;
import ttc.driver.service.PickupStatusService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pickup-statuses")
public class PickupStatusController {

    @Autowired
    private PickupStatusService pickupStatusService;

    @GetMapping
    public List<PickupStatusDTO> getAllStatuses() {
        return pickupStatusService.getAllStatuses();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PickupStatusDTO> getStatusById(@PathVariable Integer id) {
        PickupStatusDTO dto = pickupStatusService.getStatusById(id);
        return dto != null ? ResponseEntity.ok(dto) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public PickupStatusDTO createStatus(@RequestBody PickupStatusDTO pickupStatusDTO) {
        return pickupStatusService.createStatus(pickupStatusDTO);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PickupStatusDTO> updateStatus(@PathVariable Integer id, @RequestBody PickupStatusDTO pickupStatusDTO) {
        PickupStatusDTO updatedStatus = pickupStatusService.updateStatus(id, pickupStatusDTO);
        return ResponseEntity.ok(updatedStatus);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStatus(@PathVariable Integer id) {
        pickupStatusService.deleteStatus(id);
        return ResponseEntity.noContent().build();
    }
}
