package ttc.driver.service;

import ttc.driver.dto.DriverStatusDTO;

import java.util.List;

public interface DriverStatusService {
    DriverStatusDTO createDriverStatus(DriverStatusDTO driverStatusDTO);
    DriverStatusDTO updateDriverStatus(int id, DriverStatusDTO driverStatusDTO);
    void deleteDriverStatus(int id);
    DriverStatusDTO getDriverStatusById(int id);
    List<DriverStatusDTO> getAllDriverStatuses();
}
