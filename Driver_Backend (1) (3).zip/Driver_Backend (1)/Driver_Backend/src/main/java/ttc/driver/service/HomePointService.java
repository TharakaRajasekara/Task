package ttc.driver.service;

import ttc.driver.dto.HomePointDTO;
import ttc.driver.entity.HomePoint;

import java.util.List;

public interface HomePointService {
    HomePointDTO createHomePoint(HomePointDTO homePointDTO);
    HomePointDTO updateHomePoint(int hpId, HomePointDTO homePointDTO);
    void deleteHomePoint(int hpId);
    HomePointDTO getHomePointById(int hpId);
    List<HomePointDTO> getAllHomePoints();
}
