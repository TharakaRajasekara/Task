package ttc.driver.service;

import ttc.driver.dto.UserDTO;

public interface AuthService {
    boolean loginUser(UserDTO user);
}
