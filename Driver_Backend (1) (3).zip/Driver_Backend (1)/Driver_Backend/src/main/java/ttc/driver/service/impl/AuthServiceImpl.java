package ttc.driver.service.impl;

import ttc.driver.dto.UserDTO;
import ttc.driver.repository.UserRepository;
import ttc.driver.service.AuthService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public boolean loginUser(UserDTO user) {
        // Simulate authentication logic, replace with your actual logic
        if (user.getName().equals("username") && user.getMobile().equals("password")) {
            return true;
        }
        return false;
    }
}
