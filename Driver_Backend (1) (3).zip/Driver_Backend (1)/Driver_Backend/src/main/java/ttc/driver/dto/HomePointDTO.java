package ttc.driver.dto;

public class HomePointDTO {
    private int hpId;
    private int userId;
    private int timeslotId;
    private String location;
    private int itemListId;

    public HomePointDTO() {
    }

    public HomePointDTO(int hpId, int userId, int timeslotId, String location, int itemListId) {
        this.hpId = hpId;
        this.userId = userId;
        this.timeslotId = timeslotId;
        this.location = location;
        this.itemListId = itemListId;
    }

    public int getHpId() {
        return hpId;
    }

    public void setHpId(int hpId) {
        this.hpId = hpId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getTimeslotId() {
        return timeslotId;
    }

    public void setTimeslotId(int timeslotId) {
        this.timeslotId = timeslotId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getItemListId() {
        return itemListId;
    }

    public void setItemListId(int itemListId) {
        this.itemListId = itemListId;
    }
}
