package ttc.driver.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ttc.driver.dto.CsrfTokenDto;
import ttc.driver.entity.CsrfToken;
import ttc.driver.repository.CsrfTokenRepository;
import ttc.driver.service.CsrfTokenService;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CsrfTokenServiceImpl implements CsrfTokenService {

    @Autowired
    private CsrfTokenRepository csrfTokenRepository;

    @Override
    public CsrfTokenDto createCsrfToken(CsrfTokenDto csrfTokenDto) {
        CsrfToken csrfToken = new CsrfToken(
                csrfTokenDto.getParameterName(),
                csrfTokenDto.getToken(),
                csrfTokenDto.getHeaderName()
        );
        CsrfToken savedToken = csrfTokenRepository.save(csrfToken);
        return new CsrfTokenDto(savedToken.getId(), savedToken.getParameterName(), savedToken.getToken(), savedToken.getHeaderName());
    }

    @Override
    public CsrfTokenDto getCsrfTokenById(Long id) {
        Optional<CsrfToken> csrfToken = csrfTokenRepository.findById(id);
        if (csrfToken.isPresent()) {
            CsrfToken token = csrfToken.get();
            return new CsrfTokenDto(token.getId(), token.getParameterName(), token.getToken(), token.getHeaderName());
        } else {
            throw new RuntimeException("CsrfToken not found");
        }
    }

    @Override
    public List<CsrfTokenDto> getAllCsrfTokens() {
        return csrfTokenRepository.findAll().stream()
                .map(token -> new CsrfTokenDto(token.getId(), token.getParameterName(), token.getToken(), token.getHeaderName()))
                .collect(Collectors.toList());
    }

    @Override
    public CsrfTokenDto updateCsrfToken(Long id, CsrfTokenDto csrfTokenDto) {
        Optional<CsrfToken> csrfToken = csrfTokenRepository.findById(id);
        if (csrfToken.isPresent()) {
            CsrfToken existingToken = csrfToken.get();
            existingToken.setParameterName(csrfTokenDto.getParameterName());
            existingToken.setToken(csrfTokenDto.getToken());
            existingToken.setHeaderName(csrfTokenDto.getHeaderName());
            CsrfToken updatedToken = csrfTokenRepository.save(existingToken);
            return new CsrfTokenDto(updatedToken.getId(), updatedToken.getParameterName(), updatedToken.getToken(), updatedToken.getHeaderName());
        } else {
            throw new RuntimeException("CsrfToken not found");
        }
    }

    @Override
    public void deleteCsrfToken(Long id) {
        csrfTokenRepository.deleteById(id);
    }
}