package ttc.driver.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ttc.driver.entity.HomePoint;

public interface HomePointRepository extends JpaRepository<HomePoint, Integer> {
}
