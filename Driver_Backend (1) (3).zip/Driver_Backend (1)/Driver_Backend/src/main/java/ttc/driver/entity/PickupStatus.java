package ttc.driver.entity;

import javax.persistence.*;

@Entity
public class PickupStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pickupStatusId;

    private String status;

    // Getters and Setters

    public Integer getPickupStatusId() {
        return pickupStatusId;
    }

    public void setPickupStatusId(Integer pickupStatusId) {
        this.pickupStatusId = pickupStatusId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "PickupStatus{" +
                "pickupStatusId=" + pickupStatusId +
                ", status='" + status + '\'' +
                '}';
    }


    public Integer getId() {
        return null;
    }
}


