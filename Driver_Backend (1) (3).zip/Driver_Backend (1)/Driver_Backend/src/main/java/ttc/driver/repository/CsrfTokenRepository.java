package ttc.driver.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import ttc.driver.entity.CsrfToken;

@EnableJpaRepositories
public interface CsrfTokenRepository extends JpaRepository<CsrfToken, Long> {
}