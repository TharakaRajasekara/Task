package ttc.driver.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ttc.driver.entity.Driver;

public interface DriverRepository extends JpaRepository<Driver, Integer> {
}
