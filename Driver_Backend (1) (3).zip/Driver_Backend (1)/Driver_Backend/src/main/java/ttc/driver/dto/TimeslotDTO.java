package ttc.driver.dto;

import java.time.LocalDateTime;

public class TimeslotDTO {

    private int id;
    private LocalDateTime date;
    private LocalDateTime from;
    private LocalDateTime to;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public LocalDateTime getFrom() {
        return from;
    }

    public void setFrom(LocalDateTime from) {
        this.from = from;
    }

    public LocalDateTime getTo() {
        return to;
    }

    public void setTo(LocalDateTime to) {
        this.to = to;
    }

    @Override
    public String toString() {
        return "TimeslotDTO{" +
                "id=" + id +
                ", date=" + date +
                ", from=" + from +
                ", to=" + to +
                '}';
    }
}
