package ttc.driver.service.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ttc.driver.dto.CardDTO;
import ttc.driver.entity.Card;
import ttc.driver.repository.CardRepository;
import ttc.driver.service.CardService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CardServiceImpl implements CardService {

    @Autowired
    private CardRepository cardRepository;

    @Override
    public CardDTO createCard(CardDTO cardDTO) {
        Card card = new Card(cardDTO.getTitle(), cardDTO.getContent());
        card = cardRepository.save(card);
        return new CardDTO(card.getId(), card.getTitle(), card.getContent());
    }

    @Override
    public CardDTO getCardById(Long id) {
        Card card = cardRepository.findById(id).orElseThrow(() -> new RuntimeException("Card not found"));
        return new CardDTO(card.getId(), card.getTitle(), card.getContent());
    }

    @Override
    public List<CardDTO> getAllCards() {
        return cardRepository.findAll().stream()
                .map(card -> new CardDTO(card.getId(), card.getTitle(), card.getContent()))
                .collect(Collectors.toList());
    }

    @Override
    public CardDTO updateCard(Long id, CardDTO cardDTO) {
        Card card = cardRepository.findById(id).orElseThrow(() -> new RuntimeException("Card not found"));
        card.setTitle(cardDTO.getTitle());
        card.setContent(cardDTO.getContent());
        card = cardRepository.save(card);
        return new CardDTO(card.getId(), card.getTitle(), card.getContent());
    }

    @Override
    public void deleteCard(Long id) {
        Card card = cardRepository.findById(id).orElseThrow(() -> new RuntimeException("Card not found"));
        cardRepository.delete(card);
    }
}
