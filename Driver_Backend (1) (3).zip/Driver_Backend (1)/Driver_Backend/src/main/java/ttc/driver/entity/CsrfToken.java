package ttc.driver.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class CsrfToken {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String parameterName;
    private String token;
    private String headerName;

    // Constructors, getters, and setters

    public CsrfToken() {}

    public CsrfToken(String parameterName, String token, String headerName) {
        this.parameterName = parameterName;
        this.token = token;
        this.headerName = headerName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getParameterName() {
        return parameterName;
    }

    public void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getHeaderName() {
        return headerName;
    }

    public void setHeaderName(String headerName) {
        this.headerName = headerName;
    }

    @Override
    public String toString() {
        return "CsrfToken{" +
                "id=" + id +
                ", parameterName='" + parameterName + '\'' +
                ", token='" + token + '\'' +
                ", headerName='" + headerName + '\'' +
                '}';
    }
}
