package ttc.driver.controller;

import ttc.driver.dto.UserDTO;
import ttc.driver.service.AuthService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RequestMapping("/api/v1/Driver/login")
@RestController
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private RestTemplate restTemplate;

    private static final String OTP_SEND_ENDPOINT = "http://ec2-52-77-255-172.ap-southeast-1.compute.amazonaws.com:8080/ttc/otp/send/";

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody UserDTO userDTO) {
        String phoneNumber = userDTO.getMobile();

        // Create headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        // Add authorization header if required
        // headers.set("Authorization", "Bearer YOUR_API_KEY");

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        // Sending OTP
        ResponseEntity<String> response = restTemplate.exchange(
                OTP_SEND_ENDPOINT + phoneNumber,
                HttpMethod.POST,
                entity,
                String.class
        );

        if (response.getStatusCode() == HttpStatus.OK) {
            return new ResponseEntity<>("OTP Sent. Please verify", HttpStatus.OK);
        } else {
            // Debugging the response
            System.out.println("Response Status: " + response.getStatusCode());
            System.out.println("Response Body: " + response.getBody());
            return new ResponseEntity<>("Failed to send OTP", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Uncomment and implement the OTP verification endpoint as needed
    // @PostMapping("/verifyOTP")
    // public ResponseEntity<String> verifyOTP(@RequestBody UserDTO userDTO) {
    //     String phoneNumber = userDTO.getMobile();
    //     String otp = userDTO.getOtp();

    //     // Verify OTP
    //     String verifyEndpoint = "http://ec2-52-77-255-172.ap-southeast-1.compute.amazonaws.com:8080/ttc/otp/login/verify/" + phoneNumber + "/" + otp;
    //     HttpHeaders headers = new HttpHeaders();
    //     headers.setContentType(MediaType.APPLICATION_JSON);

    //     // Add authorization header if required
    //     // headers.set("Authorization", "Bearer YOUR_API_KEY");

    //     HttpEntity<String> entity = new HttpEntity<>(null, headers);

    //     ResponseEntity<String> response = restTemplate.exchange(
    //             verifyEndpoint,
    //             HttpMethod.POST,
    //             entity,
    //             String.class
    //     );

    //     if (response.getStatusCode() == HttpStatus.OK) {
    //         if (authService.loginUser(userDTO)) {
    //             return new ResponseEntity<>("Login successful", HttpStatus.OK);
    //         } else {
    //             return new ResponseEntity<>("Invalid username or password", HttpStatus.UNAUTHORIZED);
    //         }
    //     } else {
    //         return new ResponseEntity<>("Invalid OTP", HttpStatus.UNAUTHORIZED);
    //     }
    // }
}
