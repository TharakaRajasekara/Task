package ttc.driver.controller;

import ttc.driver.dto.HomePointDTO;
import ttc.driver.service.HomePointService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/homepoints")
public class HomePointController {

    @Autowired
    private HomePointService homePointService;

    @GetMapping
    public List<HomePointDTO> getAllHomePoints() {
        return homePointService.getAllHomePoints();
    }

    @GetMapping("/{id}")
    public ResponseEntity<HomePointDTO> getHomePointById(@PathVariable int id) {
        return ResponseEntity.ok(homePointService.getHomePointById(id));
    }

    @PostMapping
    public ResponseEntity<HomePointDTO> createHomePoint(@RequestBody HomePointDTO homePointDTO) {
        return ResponseEntity.ok(homePointService.createHomePoint(homePointDTO));
    }

    @PutMapping("/{id}")
    public ResponseEntity<HomePointDTO> updateHomePoint(@PathVariable int id, @RequestBody HomePointDTO homePointDTO) {
        return ResponseEntity.ok(homePointService.updateHomePoint(id, homePointDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteHomePoint(@PathVariable int id) {
        homePointService.deleteHomePoint(id);
        return ResponseEntity.noContent().build();
    }
}
