package ttc.driver.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import ttc.driver.service.EncryptionService;

@RestController
@RequestMapping("/api/data")
public class DataController {

    @Autowired
    private EncryptionService encryptionService;

    @PostMapping("/encrypt")
    public String encryptData(@RequestBody String data) {
        String encryptedData = encryptionService.encrypt(data);
        return encryptedData;
    }

    @PostMapping("/decrypt")
    public String decryptData(@RequestBody String encryptedData) {
        String decryptedData = encryptionService.decrypt(encryptedData);
        return decryptedData;
    }
}

