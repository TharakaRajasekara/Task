package ttc.driver.controller;

import ttc.driver.dto.DriverDTO;
import ttc.driver.service.DriverService;
import ttc.driver.util.CryptoUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/drivers")
public class DriverController {

    private final DriverService driverService;

    @Autowired
    public DriverController(DriverService driverService) {
        this.driverService = driverService;
    }

    @GetMapping("/mobile/{mobile}")
    public ResponseEntity<DriverDTO> getDriverByMobile(@PathVariable String mobile) {
        return ResponseEntity.ok(driverService.getDriverByMobile(mobile));
    }

    @PostMapping
    public DriverDTO createDriver(@RequestBody DriverDTO driverDTO) {
        return driverService.createDriver(driverDTO);
    }

    @GetMapping
    public List<DriverDTO> getAllDrivers() {
        return driverService.getAllDrivers();
    }

    // Other endpoints

    @GetMapping("/decrypt/{mobile}")
    public ResponseEntity<String> decryptMobile(@PathVariable String mobile) {
        try {
            return ResponseEntity.ok(CryptoUtil.decrypt(mobile));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error decrypting mobile: " + e.getMessage());
        }
    }

    @GetMapping("/encrypt/{mobile}")
    public ResponseEntity<String> encryptMobile(@PathVariable String mobile) {
        try {
            return ResponseEntity.ok(CryptoUtil.encrypt(mobile));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error encrypting mobile: " + e.getMessage());
        }
    }
}
