package ttc.driver.dto;

import java.sql.Time;
import java.sql.Date;

public class TimeslotDTO {

    private int id;
    private Date date;
    private Time from;
    private Time to;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Time getFrom() {
        return from;
    }

    public void setFrom(Time from) {
        this.from = from;
    }

    public Time getTo() {
        return to;
    }

    public void setTo(Time to) {
        this.to = to;
    }

    @Override
    public String toString() {
        return "TimeslotDTO{" +
                "id=" + id +
                ", date=" + date +
                ", from=" + from +
                ", to=" + to +
                '}';
    }
}
