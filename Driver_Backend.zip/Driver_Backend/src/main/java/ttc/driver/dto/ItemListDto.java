package ttc.driver.dto;


public class ItemListDto {

    private int id;
    private int pct;
    private int papers;
    private int gbottles;
    private int books;
    private int clothes;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPct() {
        return pct;
    }

    public void setPct(int pct) {
        this.pct = pct;
    }

    public int getPapers() {
        return papers;
    }

    public void setPapers(int papers) {
        this.papers = papers;
    }

    public int getGbottles() {
        return gbottles;
    }

    public void setGbottles(int gbottles) {
        this.gbottles = gbottles;
    }

    public int getBooks() {
        return books;
    }

    public void setBooks(int books) {
        this.books = books;
    }

    public int getClothes() {
        return clothes;
    }

    public void setClothes(int clothes) {
        this.clothes = clothes;
    }

    @Override
    public String toString() {
        return "ItemListDto{" +
                "id=" + id +
                ", pct=" + pct +
                ", papers=" + papers +
                ", gbottles=" + gbottles +
                ", books=" + books +
                ", clothes=" + clothes +
                '}';
    }
}
