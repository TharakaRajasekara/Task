package ttc.driver.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springdoc.core.GroupedOpenApi;

@Configuration
@EnableWebSecurity
public class SwaggerConfig extends WebSecurityConfigurerAdapter {

    @Bean
    public GroupedOpenApi publicApi() {
        return GroupedOpenApi.builder()
                .group("springshop-public")
                .pathsToMatch("/**")
                .build();
    }

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info().title("T2C DriverAPI").version("1.0.0").description("Driver Server For T2C Documentation"));
    }

    @Bean
    public InMemoryUserDetailsManager userDetailsService() {
        UserDetails user = User.withDefaultPasswordEncoder()
                .username("root")
                .password("Ts@1102r")
                .roles("User")
                .build();
        return new InMemoryUserDetailsManager(user);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .authorizeRequests()
                .antMatchers("/api/v1/Driver/login").authenticated() // Secure this endpoint
                .antMatchers("/api/homepoints").authenticated() // Secure this endpoint
                .antMatchers("/items").authenticated() // Secure this endpoint
                .antMatchers("/user/profile").authenticated() // Secure this endpoint
                .antMatchers("/drivers").authenticated() // Secure this endpoint
                .antMatchers("/api/timeslots").authenticated() // Secure this endpoint
                .antMatchers("/api/pickup-statuses").authenticated() // Secure this endpoint
                .anyRequest().permitAll() // Allow all other requests
                .and()
                .httpBasic(); // Use HTTP Basic Authentication
    }
}
