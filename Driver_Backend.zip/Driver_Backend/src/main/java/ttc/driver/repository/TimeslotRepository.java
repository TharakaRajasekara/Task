package ttc.driver.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import ttc.driver.entity.Timeslot;

@EnableJpaRepositories
public interface TimeslotRepository extends JpaRepository<Timeslot, Integer> {
}

