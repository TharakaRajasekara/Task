package ttc.driver.service;

import ttc.driver.dto.DriverDTO;
import java.util.List;

public interface DriverService {
    DriverDTO getDriverByMobile(String mobile);
    DriverDTO createDriver(DriverDTO driverDTO);
    List<DriverDTO> getAllDrivers();

    // Additional methods for encryption/decryption if needed
    String encryptMobile(String mobile) throws Exception;
    String decryptMobile(String encryptedMobile) throws Exception;
}
