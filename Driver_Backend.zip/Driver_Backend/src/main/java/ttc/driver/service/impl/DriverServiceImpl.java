package ttc.driver.service.impl;

import ttc.driver.dto.DriverDTO;
import ttc.driver.entity.Driver;
import ttc.driver.repository.DriverRepository;
import ttc.driver.service.DriverService;
import ttc.driver.util.CryptoUtil;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DriverServiceImpl implements DriverService {

    private final DriverRepository driverRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public DriverServiceImpl(DriverRepository driverRepository, ModelMapper modelMapper) {
        this.driverRepository = driverRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public DriverDTO getDriverByMobile(String mobile) {
        try {
            String encryptedMobile = CryptoUtil.encrypt(mobile);
            Driver driver = driverRepository.findByMobile(encryptedMobile)
                    .orElseThrow(() -> new RuntimeException("Driver not found"));
            return modelMapper.map(driver, DriverDTO.class);
        } catch (Exception e) {
            throw new RuntimeException("Error occurred while fetching the driver", e);
        }
    }

    @Override
    public DriverDTO createDriver(DriverDTO driverDTO) {
        try {
            driverDTO.setMobile(CryptoUtil.encrypt(driverDTO.getMobile()));
            Driver driver = modelMapper.map(driverDTO, Driver.class);
            Driver savedDriver = driverRepository.save(driver);
            return modelMapper.map(savedDriver, DriverDTO.class);
        } catch (Exception e) {
            throw new RuntimeException("Error occurred while creating the driver", e);
        }
    }

    @Override
    public List<DriverDTO> getAllDrivers() {
        return driverRepository.findAll().stream()
                .map(driver -> {
                    DriverDTO driverDTO = modelMapper.map(driver, DriverDTO.class);
                    try {
                        driverDTO.setMobile(CryptoUtil.decrypt(driverDTO.getMobile()));
                    } catch (Exception e) {
                        throw new RuntimeException("Error occurred while decrypting mobile", e);
                    }
                    return driverDTO;
                })
                .collect(Collectors.toList());
    }

    @Override
    public String encryptMobile(String mobile) throws Exception {
        return null;
    }

    @Override
    public String decryptMobile(String encryptedMobile) throws Exception {
        return null;
    }

    // other method implementations
}
