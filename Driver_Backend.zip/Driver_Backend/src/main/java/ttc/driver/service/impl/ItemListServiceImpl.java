package ttc.driver.service.impl;
import ttc.driver.dto.ItemListDto;
import ttc.driver.entity.ItemList;
import ttc.driver.repository.ItemListRepository;
import ttc.driver.service.ItemListService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ItemListServiceImpl implements ItemListService {

    @Autowired
    private ItemListRepository itemListRepository;

    @Override
    public List<ItemListDto> getAllItems() {
        return itemListRepository.findAll().stream().map(this::convertToDto).collect(Collectors.toList());
    }

    @Override
    public ItemListDto getItemById(int id) {
        return itemListRepository.findById(id).map(this::convertToDto).orElse(null);
    }

    @Override
    public ItemListDto createItem(ItemListDto itemListDto) {
        ItemList item = convertToEntity(itemListDto);
        return convertToDto(itemListRepository.save(item));
    }

    @Override
    public ItemListDto updateItem(int id, ItemListDto itemListDto) {
        if (itemListRepository.existsById(id)) {
            ItemList item = convertToEntity(itemListDto);
            item.setId(id);
            return convertToDto(itemListRepository.save(item));
        }
        return null;
    }

    @Override
    public void deleteItem(int id) {
        if (itemListRepository.existsById(id)) {
            itemListRepository.deleteById(id);
        }
    }

    private ItemListDto convertToDto(ItemList item) {
        ItemListDto dto = new ItemListDto();
        dto.setId(item.getId());
        dto.setPct(item.getPct());
        dto.setPapers(item.getPapers());
        dto.setGbottles(item.getGbottles());
        dto.setBooks(item.getBooks());
        dto.setClothes(item.getClothes());
        return dto;
    }

    private ItemList convertToEntity(ItemListDto dto) {
        ItemList item = new ItemList();
        item.setPct(dto.getPct());
        item.setPapers(dto.getPapers());
        item.setGbottles(dto.getGbottles());
        item.setBooks(dto.getBooks());
        item.setClothes(dto.getClothes());
        return item;
    }
}
