package ttc.driver.service;


import java.util.List;

import ttc.driver.dto.TimeslotDTO;

public interface TimeslotService {
    TimeslotDTO createTimeslot(TimeslotDTO timeslotDTO);
    TimeslotDTO getTimeslotById(int id);
    List<TimeslotDTO> getAllTimeslots();
    TimeslotDTO updateTimeslot(int id, TimeslotDTO timeslotDTO);
    void deleteTimeslot(int id);
}
