package ttc.driver.service;

import java.util.List;

import ttc.driver.dto.HomePointDTO;

public interface HomePointService {

    List<HomePointDTO> getAllHomePoints();
    HomePointDTO getHomePointById(int hpId);
    HomePointDTO createHomePoint(HomePointDTO homePointDTO);
    HomePointDTO updateHomePoint(int hpId, HomePointDTO homePointDTO);
    void deleteHomePoint(int hpId);

}
