package ttc.driver.entity;

import javax.persistence.*;

@Entity
@Table(name = "home_point")
public class HomePoint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int hpId;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "timeslot_id", nullable = false)
    private Timeslot timeslot;

    private int points;

    @ManyToOne
    @JoinColumn(name = "pickup_status_id", nullable = false)
    private PickupStatus pickupStatus;

    private String location;

    @ManyToOne
    @JoinColumn(name = "item_list_id", nullable = false)
    private ItemList itemList;

    @ManyToOne
    @JoinColumn(name = "driver_id", nullable = false)
    private Driver driver;

    // Getters and setters

    public HomePoint() {
    }

    public HomePoint(int hpId, User user, Timeslot timeslot, int points, PickupStatus pickupStatus, String location, ItemList itemList, Driver driver) {
        this.hpId = hpId;
        this.user = user;
        this.timeslot = timeslot;
        this.points = points;
        this.pickupStatus = pickupStatus;
        this.location = location;
        this.itemList = itemList;
        this.driver = driver;
    }

    public int getHpId() {
        return hpId;
    }

    public void setHpId(int hpId) {
        this.hpId = hpId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Timeslot getTimeslot() {
        return timeslot;
    }

    public void setTimeslot(Timeslot timeslot) {
        this.timeslot = timeslot;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public PickupStatus getPickupStatus() {
        return pickupStatus;
    }

    public void setPickupStatus(PickupStatus pickupStatus) {
        this.pickupStatus = pickupStatus;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public ItemList getItemList() {
        return itemList;
    }

    public void setItemList(ItemList itemList) {
        this.itemList = itemList;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    @Override
    public String toString() {
        return "HomePoint{" +
                "hpId=" + hpId +
                ", user=" + user +
                ", timeslot=" + timeslot +
                ", points=" + points +
                ", pickupStatus=" + pickupStatus +
                ", location='" + location + '\'' +
                ", itemList=" + itemList +
                ", driver=" + driver +
                '}';
    }
}
