package ttc.driver.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "driver")
public class Driver {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer driver_id;

    @Column(name = "name", nullable = false, length = 70)
    private String name;

    @Column(name = "email", nullable = false, length = 60)
    private String email;

    @Column(name = "mobile", nullable = false, length = 12)
    private String mobile;

    @Column(name = "pfp_link", length = 255)
    private String pfp_link;

    @Column(name = "created_at", nullable = false)
    private Timestamp created_at;

    @Column(name = "updated_at", nullable = false)
    private Timestamp updated_at;

    @Column(name = "last_online")
    private Timestamp last_online;

    @ManyToOne
    @JoinColumn(name = "driver_status_id", nullable = false)
    private DriverStatus driverStatus;

    // Constructors
    public Driver() {
    }

    public Driver(String name, String email, String mobile, String pfp_link, Timestamp created_at, Timestamp updated_at, Timestamp last_online, DriverStatus driverStatus) {
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.pfp_link = pfp_link;
        this.created_at = created_at;
        this.updated_at = updated_at;
        this.last_online = last_online;
        this.driverStatus = driverStatus;
    }

    // Getters and Setters
    public Integer getDriver_id() {
        return driver_id;
    }

    public void setDriver_id(Integer driver_id) {
        this.driver_id = driver_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPfp_link() {
        return pfp_link;
    }

    public void setPfp_link(String pfp_link) {
        this.pfp_link = pfp_link;
    }

    public Timestamp getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Timestamp created_at) {
        this.created_at = created_at;
    }

    public Timestamp getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(Timestamp updated_at) {
        this.updated_at = updated_at;
    }

    public Timestamp getLast_online() {
        return last_online;
    }

    public void setLast_online(Timestamp last_online) {
        this.last_online = last_online;
    }

    public DriverStatus getDriverStatus() {
        return driverStatus;
    }

    public void setDriverStatus(DriverStatus driverStatus) {
        this.driverStatus = driverStatus;
    }

    // toString method
    @Override
    public String toString() {
        return "Driver{" +
                "driver_id=" + driver_id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", mobile='" + mobile + '\'' +
                ", pfp_link='" + pfp_link + '\'' +
                ", created_at=" + created_at +
                ", updated_at=" + updated_at +
                ", last_online=" + last_online +
                ", driverStatus=" + driverStatus +
                '}';
    }
}