package T2C.DriverLogin.Service;

import T2C.DriverLogin.DTO.OrderDTO;

public interface OrderService {
    OrderDTO createOrder(OrderDTO orderDTO);

    // Other methods for CRUD operations
}
