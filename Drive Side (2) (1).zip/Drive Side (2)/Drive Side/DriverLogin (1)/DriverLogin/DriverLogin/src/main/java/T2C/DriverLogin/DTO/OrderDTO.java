package T2C.DriverLogin.DTO;

public class OrderDTO {
    private String itemName;
    private double weightKg;

    public OrderDTO() {
    }

    public OrderDTO(String itemName, double weightKg) {
        this.itemName = itemName;
        this.weightKg = weightKg;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setWeightKg(double weightKg) {
        this.weightKg = weightKg;
    }

    @Override
    public String toString() {
        return "OrderDTO{" +
                "itemName='" + itemName + '\'' +
                ", weightKg=" + weightKg +
                '}';
    }


    public String getItemName() {
        return null;
    }

    public double getWeightKg() {
        return 0;
    }
}
