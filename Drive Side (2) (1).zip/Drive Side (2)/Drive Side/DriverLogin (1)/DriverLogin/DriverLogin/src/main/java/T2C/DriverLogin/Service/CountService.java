package T2C.DriverLogin.Service;

import T2C.DriverLogin.DTO.CountDTO;

import java.util.List;

public interface CountService {
    CountDTO getCountById(Long id);
    List<CountDTO> getAllCounts();
    CountDTO createCount(CountDTO countDTO);
    void deleteCount(Long id);
}