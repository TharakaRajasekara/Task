package T2C.DriverLogin.Service.IMPL;

import T2C.DriverLogin.DTO.OrderDTO;
import T2C.DriverLogin.Entity.Order;
import T2C.DriverLogin.Repository.OrderRepository;
import T2C.DriverLogin.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderRepository orderRepository;

    @Override
    public OrderDTO createOrder(OrderDTO orderDTO) {
        Order order = new Order();
        order.setItemName(orderDTO.getItemName());
        order.setWeightKg(orderDTO.getWeightKg());
        orderRepository.save(order);
        return orderDTO;
    }
    public Order saveOrder(Order order) {
        return orderRepository.save(order);
    }
    // Other method implementations
}