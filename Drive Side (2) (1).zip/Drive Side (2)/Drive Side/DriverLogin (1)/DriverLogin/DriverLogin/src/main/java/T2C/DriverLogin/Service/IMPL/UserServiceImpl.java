package T2C.DriverLogin.Service.IMPL;

import T2C.DriverLogin.DTO.UserDTO1;
import T2C.DriverLogin.Entity.UserEntity;
import T2C.DriverLogin.Repository.UserRepository1;
import T2C.DriverLogin.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository1 userRepository;

    @Override
    public UserDTO1 getUserProfile() {
        UserEntity userEntity = userRepository.findById(1L).orElse(null); // Assuming user ID 1 for simplicity
        if (userEntity != null) {
            UserDTO1 userDTO = new UserDTO1();
            userDTO.setId(userEntity.getId());
            userDTO.setName(userEntity.getName());
            userDTO.setEmail(userEntity.getEmail());
            userDTO.setPhoneNumber(userEntity.getPhoneNumber());
            userDTO.setAddress(userEntity.getAddress());
            return userDTO;
        }
        return null;
    }
}