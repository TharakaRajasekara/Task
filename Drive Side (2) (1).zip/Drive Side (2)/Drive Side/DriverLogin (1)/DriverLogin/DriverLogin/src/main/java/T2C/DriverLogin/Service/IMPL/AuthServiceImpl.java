package T2C.DriverLogin.Service.IMPL;

import T2C.DriverLogin.DTO.UserDTO;
import T2C.DriverLogin.Repository.UserRepository;
import T2C.DriverLogin.Service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public boolean loginUser(UserDTO user) {
        // Simulate authentication logic, replace with your actual logic
        if (user.getUsername().equals("username") && user.getPassword().equals("password")) {
            return true;
        }
        return false;
    }
}
