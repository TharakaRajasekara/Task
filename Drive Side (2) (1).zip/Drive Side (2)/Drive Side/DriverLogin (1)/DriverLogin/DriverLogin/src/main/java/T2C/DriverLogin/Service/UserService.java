package T2C.DriverLogin.Service;

import T2C.DriverLogin.DTO.UserDTO1;

public interface UserService {
    UserDTO1 getUserProfile();
}
