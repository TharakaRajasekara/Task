package T2C.DriverLogin.DTO;

public class DriverDTO {
    private String name;
    private String licenseNumber;
    // other fields, constructors, getters/setters

    public DriverDTO() {
    }

    public DriverDTO(String name, String licenseNumber) {
        this.name = name;
        this.licenseNumber = licenseNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    @Override
    public String toString() {
        return "DriverDTO{" +
                "name='" + name + '\'' +
                ", licenseNumber='" + licenseNumber + '\'' +
                '}';
    }
}