package ttc.driver.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ttc.driver.dto.HomePointDTO;
import ttc.driver.service.HomePointService;

import java.util.List;

@RestController
@RequestMapping("/homepoints")
public class HomePointController {

    @Autowired
    private HomePointService homePointService;

    @PostMapping
    public ResponseEntity<HomePointDTO> createHomePoint(@RequestBody HomePointDTO homePointDTO) {
        HomePointDTO createdHomePoint = homePointService.createHomePoint(homePointDTO);
        return ResponseEntity.ok(createdHomePoint);
    }

    @PutMapping("/{hpId}")
    public ResponseEntity<HomePointDTO> updateHomePoint(@PathVariable int hpId, @RequestBody HomePointDTO homePointDTO) {
        HomePointDTO updatedHomePoint = homePointService.updateHomePoint(hpId, homePointDTO);
        return ResponseEntity.ok(updatedHomePoint);
    }

    @DeleteMapping("/{hpId}")
    public ResponseEntity<Void> deleteHomePoint(@PathVariable int hpId) {
        homePointService.deleteHomePoint(hpId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{hpId}")
    public ResponseEntity<HomePointDTO> getHomePointById(@PathVariable int hpId) {
        HomePointDTO homePointDTO = homePointService.getHomePointById(hpId);
        return ResponseEntity.ok(homePointDTO);
    }

    @GetMapping
    public ResponseEntity<List<HomePointDTO>> getAllHomePoints() {
        List<HomePointDTO> homePoints = homePointService.getAllHomePoints();
        return ResponseEntity.ok(homePoints);
    }
}
