package ttc.driver.dto;



import java.sql.Timestamp;

public class PickupDTO {
    private int hpId;
    private int driverId;
    private int points;
    private Timestamp pickupTime;
    private int pickupStatusId;

    public PickupDTO() {
    }

    public PickupDTO(int hpId, int driverId, int points, Timestamp pickupTime, int pickupStatusId) {
        this.hpId = hpId;
        this.driverId = driverId;
        this.points = points;
        this.pickupTime = pickupTime;
        this.pickupStatusId = pickupStatusId;
    }

    public int getHpId() {
        return hpId;
    }

    public void setHpId(int hpId) {
        this.hpId = hpId;
    }

    public int getDriverId() {
        return driverId;
    }

    public void setDriverId(int driverId) {
        this.driverId = driverId;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public Timestamp getPickupTime() {
        return pickupTime;
    }

    public void setPickupTime(Timestamp pickupTime) {
        this.pickupTime = pickupTime;
    }

    public int getPickupStatusId() {
        return pickupStatusId;
    }

    public void setPickupStatusId(int pickupStatusId) {
        this.pickupStatusId = pickupStatusId;
    }

    @Override
    public String toString() {
        return "PickupDTO{" +
                "hpId=" + hpId +
                ", driverId=" + driverId +
                ", points=" + points +
                ", pickupTime=" + pickupTime +
                ", pickupStatusId=" + pickupStatusId +
                '}';
    }
}
