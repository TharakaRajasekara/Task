package ttc.driver.controller;

import ttc.driver.dto.UserDTO;
import ttc.driver.service.AuthService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RequestMapping("/api/v1/Driver/login")
@RestController
public class AuthController {


    @Autowired
    private AuthService authService;

    // Inject RestTemplate to make HTTP requests
    @Autowired
    private RestTemplate restTemplate;

    // OTP endpoint for sending OTP
    private static final String OTP_SEND_ENDPOINT = "http://ec2-52-77-255-172.ap-southeast-1.compute.amazonaws.com:8080/ttc/otp/send/";

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody UserDTO userDTO) {
        // Assuming userDTO contains phoneNumber field
        String phoneNumber = userDTO.getMobile();

        // Sending OTP
        ResponseEntity<String> response = restTemplate.postForEntity(OTP_SEND_ENDPOINT + phoneNumber, null, String.class);

        if (response.getStatusCode() == HttpStatus.OK) {
            return new ResponseEntity<>("OTP Sent. Please verify", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Failed to send OTP", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // @PostMapping("/verifyOTP")
    // public ResponseEntity<String> verifyOTP(@RequestBody UserDTO userDTO) {
    //     // Assuming userDTO contains phoneNumber and otp fields
    //     String phoneNumber = userDTO.getMobile();

    //     // Verify OTP
    //     String verifyEndpoint = "http://ec2-52-77-255-172.ap-southeast-1.compute.amazonaws.com:8080/ttc/otp/login/verify/" + phoneNumber + "/" + otp;
    //     ResponseEntity<String> response = restTemplate.postForEntity(verifyEndpoint, null, String.class);

    //     if (response.getStatusCode() == HttpStatus.OK) {
    //         // OTP verified successfully, proceed with login
    //         if (authService.loginUser(userDTO)) {
    //             return new ResponseEntity<>("Login successful", HttpStatus.OK);
    //         } else {
    //             return new ResponseEntity<>("Invalid username or password", HttpStatus.UNAUTHORIZED);
    //         }
    //     } else {
    //         // OTP verification failed
    //         return new ResponseEntity<>("Invalid OTP", HttpStatus.UNAUTHORIZED);
    //     }
    // }
}