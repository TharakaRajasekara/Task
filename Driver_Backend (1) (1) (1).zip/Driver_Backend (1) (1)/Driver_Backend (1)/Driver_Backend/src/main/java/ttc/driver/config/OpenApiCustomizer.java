package ttc.driver.config;

public class OpenApiCustomizer {
}
