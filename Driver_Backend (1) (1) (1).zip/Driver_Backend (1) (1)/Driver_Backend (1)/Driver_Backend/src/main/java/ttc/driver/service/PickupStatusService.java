package ttc.driver.service;


import java.util.List;

import ttc.driver.dto.PickupStatusDTO;

public interface PickupStatusService {

    List<PickupStatusDTO> getAllStatuses();

    PickupStatusDTO getStatusById(Integer id);

    PickupStatusDTO createStatus(PickupStatusDTO pickupStatusDTO);

    PickupStatusDTO updateStatus(Integer id, PickupStatusDTO pickupStatusDTO);

    void deleteStatus(Integer id);
}
