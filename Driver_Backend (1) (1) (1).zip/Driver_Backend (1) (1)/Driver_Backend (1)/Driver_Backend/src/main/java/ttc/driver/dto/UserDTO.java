package ttc.driver.dto;

import java.sql.Timestamp;

public class UserDTO {
    private Integer user_id;
    private String name;
    private String email;
    private String mobile;
    private String pfp_link;
    private Integer available_points;
    private Timestamp created_at;
    private Timestamp updated_at;

    public UserDTO() {
    }

    public UserDTO(Integer user_id, String name, String email, String mobile, String pfp_link, Integer available_points, Timestamp created_at, Timestamp updated_at) {
        this.user_id = user_id;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.pfp_link = pfp_link;
        this.available_points = available_points;
        this.created_at = created_at;
        this.updated_at = updated_at;
    }

    // Getters
    public Integer getUser_id() {
        return user_id;
    }
    
    public String getName() {
        return name;
    }
    
    public String getEmail() {
        return email;
    }
    
    public String getMobile() {
        return mobile;
    }
    
    public String getPfp_link() {
        return pfp_link;
    }
    
    public Integer getAvailable_points() {
        return available_points;
    }
    
    public Timestamp getCreated_at() {
        return created_at;
    }
    
    public Timestamp getUpdated_at() {
        return updated_at;
    }
    
    // Setters
    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    
    public void setPfp_link(String pfp_link) {
        this.pfp_link = pfp_link;
    }
    
    public void setAvailable_points(Integer available_points) {
        this.available_points = available_points;
    }
    
    public void setCreated_at(Timestamp created_at) {
        this.created_at = created_at;
    }
    
    public void setUpdated_at(Timestamp updated_at) {
        this.updated_at = updated_at;
    }

        // toString method
    @Override
    public String toString() {
        return "UserDTO{" +
                "user_id=" + user_id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", mobile='" + mobile + '\'' +
                ", pfp_link='" + pfp_link + '\'' +
                ", available_points=" + available_points +
                ", created_at=" + created_at +
                ", updated_at=" + updated_at +
                '}';
    }
}