package ttc.driver.service;


import ttc.driver.dto.PickupDTO;

import java.util.List;

public interface PickupService {
    PickupDTO createPickup(PickupDTO pickupDTO);
    PickupDTO updatePickup(int hpId, PickupDTO pickupDTO);
    void deletePickup(int hpId);
    PickupDTO getPickupById(int hpId);
    List<PickupDTO> getAllPickups();
}
