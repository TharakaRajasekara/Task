package ttc.driver.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ttc.driver.dto.DriverDTO;
import ttc.driver.entity.Driver;
import ttc.driver.entity.DriverStatus;
import ttc.driver.repository.DriverRepository;
import ttc.driver.repository.DriverStatusRepository;
import ttc.driver.service.DriverService;

import java.sql.Timestamp;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DriverServiceImpl implements DriverService {

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private DriverStatusRepository driverStatusRepository;

    @Override
    public DriverDTO createDriver(DriverDTO driverDTO) {
        Driver driver = convertToEntity(driverDTO);
        driver.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        driver.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
        driver = driverRepository.save(driver);
        return convertToDTO(driver);
    }

    @Override
    public DriverDTO updateDriver(int id, DriverDTO driverDTO) {
        Driver driver = driverRepository.findById(id).orElseThrow(() -> new RuntimeException("Driver not found"));
        driver.setName(driverDTO.getName());
        driver.setEmail(driverDTO.getEmail());
        driver.setMobile(driverDTO.getMobile());
        driver.setPfpLink(driverDTO.getPfpLink());
        driver.setLastOnline(driverDTO.getLastOnline());
        DriverStatus driverStatus = driverStatusRepository.findById(driverDTO.getDriverStatusId())
                .orElseThrow(() -> new RuntimeException("DriverStatus not found"));
        driver.setDriverStatus(driverStatus);
        driver.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
        driver = driverRepository.save(driver);
        return convertToDTO(driver);
    }

    @Override
    public void deleteDriver(int id) {
        driverRepository.deleteById(id);
    }

    @Override
    public DriverDTO getDriverById(int id) {
        Driver driver = driverRepository.findById(id).orElseThrow(() -> new RuntimeException("Driver not found"));
        return convertToDTO(driver);
    }

    @Override
    public List<DriverDTO> getAllDrivers() {
        return driverRepository.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    private Driver convertToEntity(DriverDTO driverDTO) {
        Driver driver = new Driver();
        driver.setName(driverDTO.getName());
        driver.setEmail(driverDTO.getEmail());
        driver.setMobile(driverDTO.getMobile());
        driver.setPfpLink(driverDTO.getPfpLink());
        driver.setLastOnline(driverDTO.getLastOnline());
        DriverStatus driverStatus = driverStatusRepository.findById(driverDTO.getDriverStatusId())
                .orElseThrow(() -> new RuntimeException("DriverStatus not found"));
        driver.setDriverStatus(driverStatus);
        return driver;
    }

    private DriverDTO convertToDTO(Driver driver) {
        DriverDTO driverDTO = new DriverDTO();
        driverDTO.setId(driver.getId());
        driverDTO.setName(driver.getName());
        driverDTO.setEmail(driver.getEmail());
        driverDTO.setMobile(driver.getMobile());
        driverDTO.setPfpLink(driver.getPfpLink());
        driverDTO.setCreatedAt(driver.getCreatedAt());
        driverDTO.setUpdatedAt(driver.getUpdatedAt());
        driverDTO.setLastOnline(driver.getLastOnline());
        driverDTO.setDriverStatusId(driver.getDriverStatus().getId());
        return driverDTO;
    }
}
