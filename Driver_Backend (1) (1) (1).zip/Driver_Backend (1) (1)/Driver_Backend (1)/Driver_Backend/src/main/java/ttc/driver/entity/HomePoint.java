package ttc.driver.entity;

import javax.persistence.*;

@Entity
@Table(name = "home_point")
public class HomePoint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hp_id")
    private int hpId;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "timeslot_id", nullable = false)
    private Timeslot timeslot;

    @Column(name = "location")
    private String location;

    @ManyToOne
    @JoinColumn(name = "item_list_id", nullable = false)
    private ItemList itemList;

    // Getters and setters

    public HomePoint() {
    }

    public HomePoint(User user, Timeslot timeslot, String location, ItemList itemList) {
        this.user = user;
        this.timeslot = timeslot;
        this.location = location;
        this.itemList = itemList;
    }

    public int getHpId() {
        return hpId;
    }

    public void setHpId(int hpId) {
        this.hpId = hpId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Timeslot getTimeslot() {
        return timeslot;
    }

    public void setTimeslot(Timeslot timeslot) {
        this.timeslot = timeslot;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public ItemList getItemList() {
        return itemList;
    }

    public void setItemList(ItemList itemList) {
        this.itemList = itemList;
    }

    @Override
    public String toString() {
        return "HomePoint{" +
                "hpId=" + hpId +
                ", user=" + user +
                ", timeslot=" + timeslot +
                ", location='" + location + '\'' +
                ", itemList=" + itemList +
                '}';
    }

    public int getTimeslotId() {
        return 0;
    }

    public int getItemListId() {
        return 0;
    }

    public void setTimeslotId(int timeslotId) {
    }

    public void setItemListId(int itemListId) {
    }
}
