package ttc.driver.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ttc.driver.dto.CsrfTokenDto;
import ttc.driver.entity.CsrfToken;
import ttc.driver.service.CsrfTokenService;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/api/csrf")
public class CsrfController {

    @Autowired
    private CsrfTokenService csrfTokenService;

    @PostMapping
    public ResponseEntity<CsrfTokenDto> createCsrfToken(@RequestBody CsrfTokenDto csrfTokenDto) {
        return ResponseEntity.ok(csrfTokenService.createCsrfToken(csrfTokenDto));
    }

    @GetMapping("/v1/csrf")
    public CsrfToken csrf(HttpServletRequest request) {
        return (CsrfToken) request.getAttribute(CsrfToken.class.getName());
    }

    @GetMapping
    public ResponseEntity<List<CsrfTokenDto>> getAllCsrfTokens() {
        return ResponseEntity.ok(csrfTokenService.getAllCsrfTokens());
    }

    @PutMapping("/{id}")
    public ResponseEntity<CsrfTokenDto> updateCsrfToken(@PathVariable Long id, @RequestBody CsrfTokenDto csrfTokenDto) {
        return ResponseEntity.ok(csrfTokenService.updateCsrfToken(id, csrfTokenDto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCsrfToken(@PathVariable Long id) {
        csrfTokenService.deleteCsrfToken(id);
        return ResponseEntity.noContent().build();
    }
}