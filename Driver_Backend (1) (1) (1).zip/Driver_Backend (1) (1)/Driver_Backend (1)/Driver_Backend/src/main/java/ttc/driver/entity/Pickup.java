package ttc.driver.entity;



import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "pickup")
public class Pickup {

    @Id
    @Column(name = "hp_id")
    private int hpId;

    @OneToOne
    @MapsId
    @JoinColumn(name = "hp_id")
    private HomePoint homePoint;

    @ManyToOne
    @JoinColumn(name = "driver_id", nullable = false)
    private Driver driver;

    @ManyToOne
    @JoinColumn(name = "pickup_status_id", nullable = false)
    private PickupStatus pickupStatus;

    private int points;

    @Column(name = "pickup_time")
    private Timestamp pickupTime;

    // Getters and setters

    public int getHpId() {
        return hpId;
    }

    public void setHpId(int hpId) {
        this.hpId = hpId;
    }

    public HomePoint getHomePoint() {
        return homePoint;
    }

    public void setHomePoint(HomePoint homePoint) {
        this.homePoint = homePoint;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public PickupStatus getPickupStatus() {
        return pickupStatus;
    }

    public void setPickupStatus(PickupStatus pickupStatus) {
        this.pickupStatus = pickupStatus;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public Timestamp getPickupTime() {
        return pickupTime;
    }

    public void setPickupTime(Timestamp pickupTime) {
        this.pickupTime = pickupTime;
    }

    @Override
    public String toString() {
        return "Pickup{" +
                "hpId=" + hpId +
                ", homePoint=" + homePoint +
                ", driver=" + driver +
                ", pickupStatus=" + pickupStatus +
                ", points=" + points +
                ", pickupTime=" + pickupTime +
                '}';
    }
}

