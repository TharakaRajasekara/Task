package ttc.driver.service;


import ttc.driver.dto.CardDTO;

import java.util.List;

public interface CardService {
    CardDTO createCard(CardDTO cardDTO);
    CardDTO getCardById(Long id);
    List<CardDTO> getAllCards();
    CardDTO updateCard(Long id, CardDTO cardDTO);
    void deleteCard(Long id);



}
