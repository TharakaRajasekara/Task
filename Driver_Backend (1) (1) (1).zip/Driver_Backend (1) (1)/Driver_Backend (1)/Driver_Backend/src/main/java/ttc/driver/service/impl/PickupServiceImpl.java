package ttc.driver.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ttc.driver.dto.PickupDTO;
import ttc.driver.entity.Driver;
import ttc.driver.entity.HomePoint;
import ttc.driver.entity.Pickup;
import ttc.driver.entity.PickupStatus;
import ttc.driver.repository.DriverRepository;
import ttc.driver.repository.HomePointRepository;
import ttc.driver.repository.PickupRepository;
import ttc.driver.repository.PickupStatusRepository;
import ttc.driver.service.PickupService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PickupServiceImpl implements PickupService {

    @Autowired
    private PickupRepository pickupRepository;

    @Autowired
    private HomePointRepository homePointRepository;

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private PickupStatusRepository pickupStatusRepository;

    @Override
    public PickupDTO createPickup(PickupDTO pickupDTO) {
        Pickup pickup = new Pickup();
        HomePoint homePoint = homePointRepository.findById(pickupDTO.getHpId()).orElseThrow(() -> new RuntimeException("HomePoint not found"));
        Driver driver = driverRepository.findById(pickupDTO.getDriverId()).orElseThrow(() -> new RuntimeException("Driver not found"));
        PickupStatus pickupStatus = pickupStatusRepository.findById(pickupDTO.getPickupStatusId()).orElseThrow(() -> new RuntimeException("PickupStatus not found"));

        pickup.setHpId(pickupDTO.getHpId());
        pickup.setHomePoint(homePoint);
        pickup.setDriver(driver);
        pickup.setPoints(pickupDTO.getPoints());
        pickup.setPickupTime(pickupDTO.getPickupTime());
        pickup.setPickupStatus(pickupStatus);

        pickup = pickupRepository.save(pickup);
        return convertToDTO(pickup);
    }

    @Override
    public PickupDTO updatePickup(int hpId, PickupDTO pickupDTO) {
        Pickup pickup = pickupRepository.findById(hpId).orElseThrow(() -> new RuntimeException("Pickup not found"));
        Driver driver = driverRepository.findById(pickupDTO.getDriverId()).orElseThrow(() -> new RuntimeException("Driver not found"));
        PickupStatus pickupStatus = pickupStatusRepository.findById(pickupDTO.getPickupStatusId()).orElseThrow(() -> new RuntimeException("PickupStatus not found"));

        pickup.setDriver(driver);
        pickup.setPoints(pickupDTO.getPoints());
        pickup.setPickupTime(pickupDTO.getPickupTime());
        pickup.setPickupStatus(pickupStatus);

        pickup = pickupRepository.save(pickup);
        return convertToDTO(pickup);
    }

    @Override
    public void deletePickup(int hpId) {
        pickupRepository.deleteById(hpId);
    }

    @Override
    public PickupDTO getPickupById(int hpId) {
        Pickup pickup = pickupRepository.findById(hpId).orElseThrow(() -> new RuntimeException("Pickup not found"));
        return convertToDTO(pickup);
    }

    @Override
    public List<PickupDTO> getAllPickups() {
        return pickupRepository.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    private PickupDTO convertToDTO(Pickup pickup) {
        return new PickupDTO(
                pickup.getHpId(),
                pickup.getDriver().getDriverId(),
                pickup.getPoints(),
                pickup.getPickupTime(),
                pickup.getPickupStatus().getPickupStatusId()
        );
    }
}
