package ttc.driver.config;

import io.github.bucket4j.Bucket;
import io.github.bucket4j.Bucket4j;
import io.github.bucket4j.Refill;
import io.github.bucket4j.Bandwidth;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ttc.driver.filter.RateLimitingFilter;

import java.time.Duration;

@Configuration
public class RateLimitingConfig {

    @Bean
    public Bucket bucket() {
        Refill refill = Refill.greedy(10, Duration.ofMinutes(1));
        Bandwidth limit = Bandwidth.classic(10, refill);
        return Bucket4j.builder().addLimit(limit).build();
    }

    @Bean
    public RateLimitingFilter rateLimitingFilter(Bucket bucket) {
        return new RateLimitingFilter(bucket);
    }
}



