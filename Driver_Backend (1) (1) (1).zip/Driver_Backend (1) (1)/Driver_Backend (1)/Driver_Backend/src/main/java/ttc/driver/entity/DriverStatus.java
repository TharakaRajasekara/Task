package ttc.driver.entity;

import javax.persistence.*;

@Entity
@Table(name = "driver_status")
public class DriverStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "status", nullable = false, length = 20)
    private String status;

    // Constructors
    public DriverStatus() {
    }

    public DriverStatus(String status) {
        this.status = status;
    }

    // Getters and Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // toString method
    @Override
    public String toString() {
        return "DriverStatus{" +
                "id=" + id +
                ", status='" + status + '\'' +
                '}';
    }
}
